console.log('jail break child process')
console.log(require('fs').readdirSync(path))
