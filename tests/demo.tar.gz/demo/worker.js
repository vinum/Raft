console.log('hello from worker')
setTimeout(function() {
	console.log('bye from worker')
}, 3000)
