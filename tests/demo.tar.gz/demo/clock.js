console.log('hello from clock')

setTimeout(function() {
	console.log('bye from clock')
}, 3000)